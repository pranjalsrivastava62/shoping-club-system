# shopping_club_system
This is a shopping club system project which also gives path to the customer from their source to their destination shops in mall and also helps employee to generate bills
It will also display shops present in mall with categories
Admin:-
username: admin
password: pass


Employee: -
username: employee
password: pass
